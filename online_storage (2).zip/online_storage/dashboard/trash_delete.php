<?php

include 'connect.php';
$id = $_GET['id'];


$qq = mysqli_query($mycon, "SELECT * from file where id ='$id'");
while ($row = mysqli_fetch_assoc($qq)) {
    $destination = $row['destination'];
}

unlink($destination);

$query = mysqli_query($mycon, "DELETE FROM file where id='$id'");

if ($query) {
    echo '<script>alert("File has been deleted");</script>';
    echo '<script>location.replace("index.php");</script>';
} else {
    echo mysqli_error($query);
}
