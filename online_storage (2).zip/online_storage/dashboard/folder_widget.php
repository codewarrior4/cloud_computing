<div class="row">
    <?php
    $folder = $_GET['folder'];
    include 'connect.php';
    $query = mysqli_query($mycon, "SELECT count(folder) as id from file where  uploader_id='$ddddd' and  status='1' and folder='$folder' ");
    $query_sum = mysqli_query($mycon, "SELECT sum(size) as id from file where  uploader_id='$ddddd' and  folder='$folder' and status='1'");
   

    $row = mysqli_fetch_array($query);
    $row_sum = mysqli_fetch_array($query_sum);
    $original=round($row_sum['id']/1024,2);

    ?>
    <div class="col-lg-12">
        <div class="row">

            <div class="col-lg-6 col-xs-12">
                <div class="card p-0">
                    <div class="stat-widget-three">
                        <div class="stat-icon bg-primary p-48">
                            <i class="ti-folder"></i>
                        </div>
                        <div class="stat-content p-30">
                            <div class="stat-text"> <b><?php echo strtoupper($folder) ?></b></div>




                            <div class="stat-digit"><?php echo $row['id']; ?></div>


                        </div>
                    </div>

                </div>




            </div>

            <div class="col-lg-6 col-xs-12">

                    <div class="card p-0">
                        <div class="stat-widget-three">
                            <div class="stat-icon bg-info p-48">
                                <i class="ti-tag"></i>
                            </div>
                            <div class="stat-content p-30">
                                <div class="stat-text"> Size</div>

                                <div class="stat-digit"><?php echo $original." Mb" ?></div>
                
            </div>
        </div>
    </div>
</div>




</div>
</div>