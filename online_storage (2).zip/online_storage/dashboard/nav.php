<?php
session_start();
if (isset($_SESSION['sessionid']))
{
    $ddddd= $_SESSION['sessionid'];
}
else
{
    echo "<script>alert('You have to be logged in');</script>";
    echo '<script>window.location="../index.php";</script>';
}
?>

<div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
    <div class="nano">
        <div class="nano-content">
            <ul>
                <!-- <li class="label">Main</li> -->
                <li><a href="index.php"><i class="ti-home"></i> Home </a></li>
                <li><a href="folder.php?folder=apks"><i class="ti-android "></i> Apks </a></li>
                <li><a href="folder.php?folder=docs"><i class="ti-file "></i> Docs </a></li>
                <li><a href="folder.php?folder=images"><i class="ti-image "></i> Images </a></li>
                <li><a href="folder.php?folder=music"><i class="ti-music "></i> Music </a></li>
                <li><a href="folder.php?folder=videos"><i class="ti-video-camera "></i> Videos </a></li>
                <?php 
                    include 'connect.php';
                    $query=mysqli_query($mycon,"SELECT * from folder  WHERE uploader_id='$ddddd' ");
                    while ($row=mysqli_fetch_array($query))
                    {
                        $link=$row['name'];
                        echo  ' <li><a href="folder.php?folder='.$link.'"><i class="ti-folder "></i> '.$link.' </a></li>';
                    }
                ?>
             
                <li><a href="trashs.php"><i class="ti-trash"></i> Trash </a></li>
                <li><a href="logout.php"><i class="ti-close"></i> Logout</a></li>

            </ul>
        </div>
    </div>
</div><!-- /# sidebar -->