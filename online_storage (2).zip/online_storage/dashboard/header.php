   <div class="header" style="margin-bottom:30px">
        <div class="pull-left">
            <div class="logo"><a href="index.php"><span><i class="ti-cloud" style="font-weight:bolder;font-size:25px;"></i> Cloud Drive</span></a></div>
            <div class="hamburger sidebar-toggle">
                <span class="line"></span>
                <span class="line"></span>
                <span class="line"></span>
            </div>
        </div>

        <div class="pull-right p-r-15">
            <ul>
                <?php 


                $query=mysqli_query($mycon,"SELECT * FROM user where id='$ddddd' ");

                while($ro=mysqli_fetch_array($query))
                {
                    $name=$ro['fullname'];
                }

                ?>
                <li class="header-icon dib"> <span class="user-avatar"><?php  echo strtoupper($name); ?></span>
                </li>
            </ul>
        </div>
    </div>
