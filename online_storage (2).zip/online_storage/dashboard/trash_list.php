<div class="table-responsive">
    <table class="table table-responsive table-hover ">


        <thead>
            <tr>
                <th> Filename</th>
                <th> Size</th>
                <th>Folder</th>
                <th>Uploaded</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            include 'connect.php';
            $query = mysqli_query($mycon, "SELECT * FROM `file` where  uploader_id='$ddddd' and  status='0'  ");

            while ($row = mysqli_fetch_array($query)) {
                $name = $row['name'];
                $folder = $row['folder'];
            ?>
                <tr>
                    <td><?php echo $row['name'] ?></td>
                    <td><?php echo round($row['size']/1024,2) . "mb" ?></td>
                    <td><?php echo $row['folder'] ?></td>

                    <td><?php echo $row['uploaded'] ?></td>
                    <td><a href="trash_delete.php?id=<?php echo $row['id'] ?>"> <i class="ti-trash"></i></a><a href="trash_restore.php?id= <?php echo $row['id'] ?>"> <i class="ti-cloud-up"></i></a></td>

                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>