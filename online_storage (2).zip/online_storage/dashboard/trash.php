<?php

include 'connect.php';
$id=$_GET['id'];
$query=mysqli_query($mycon,"UPDATE file set status='0' where id='$id'");

if($query)
{
    echo '<script>alert("File has been moved to trash");</script>';
    echo '<script>location.replace("index.php");</script>';
}
else
{
    echo mysqli_error($query);
}