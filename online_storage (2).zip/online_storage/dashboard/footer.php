 <div class="row">
     <div class="col-lg-12">
         <div class="card-alert">
             <div class="card-body">
                 <b class="text-left">Designed and Developed by<a href="#" style="color:green;" target="_blank">  Adebayo Mayowa  </a> with <i style="color:red;" class="ti-heart"></i></b>
                 <?php

                    include 'connect.php';
                    $query_sum = mysqli_query($mycon, "SELECT sum(size) as id from file where  uploader_id='$ddddd'  ");

                    $row_sum = mysqli_fetch_array($query_sum);
                    $original = round($row_sum['id'] / 1024, 2);

                    ?>
                 <b style="padding-left:250px; " class="text-center">Cloud Drive Filesize  <?php echo $original . "Mb" ?> </b>
             </div>
         </div>
     </div>
 </div>