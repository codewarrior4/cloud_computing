		<?php


        if (isset($_POST['regi'])) {
            include 'dashboard/connect.php';

            $username = addslashes(strtolower($_POST['username']));
            $name = addslashes(strtolower($_POST['name']));
            $password = addslashes($_POST['password']);


            if (!empty($username) && !empty($name) && !empty($password)) {
                $query_select = mysqli_query($mycon, "SELECT * from user  where email='" . $username . "' ");

                if (mysqli_num_rows($query_select) > 0) {
                    echo  '<script>alert(" Email already exists")</script>';
                } else {
                    $query_insert = mysqli_query($mycon, "INSERT INTO user VALUES ('','$name','$email','$password',null) ");

                    if ($query_insert) {
                        echo  '<script>alert(" Account successfully Created")</script>';
                        echo  '<script>location.replace("dashboard/")</script>';
                    } else {
                        echo mysqli_error($query_insert);
                    }
                }
            } else {
                echo '<script>alert("Fields cannot appear blank");</script>';
            }
        }

        ?>