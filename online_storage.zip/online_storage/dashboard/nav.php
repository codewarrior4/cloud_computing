<div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
    <div class="nano">
        <div class="nano-content">
            <ul>
                <!-- <li class="label">Main</li> -->
                <li><a href="home.php"><i class="ti-home"></i> Home </a></li>
                <li><a href="topics.php"><i class="ti-image "></i> Images </a></li>
                <li><a href="topics.php"><i class="ti-music" ></i>Music </a></li>
                <li><a href="topics.php"><i class="ti-video-camera"></i> Video </a></li>
                <li><a href="topics.php"><i class="ti-file"></i> Docs </a></li>
                <li><a href="topics.php"><i class="ti-android"></i> Apk </a></li>
                <li><a href="topics.php"><i class="ti-trash"></i> Trash </a></li>
                <li><a href="logout.php"><i class="ti-close"></i> Logout</a></li>

            </ul>
        </div>
    </div>
</div><!-- /# sidebar -->