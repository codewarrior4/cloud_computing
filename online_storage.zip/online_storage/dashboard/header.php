   <div class="header" style="margin-bottom:30px">
        <div class="pull-left">
            <div class="logo"><a href="index.php"><span> Cloud Drive</span></a></div>
            <div class="hamburger sidebar-toggle">
                <span class="line"></span>
                <span class="line"></span>
                <span class="line"></span>
            </div>
        </div>

        <div class="pull-right p-r-15">
            <ul>

                <li class="header-icon dib"><img class="avatar-img" src="assets/images/avatar/1.jpg" alt="" /> <span class="user-avatar"><?php // echo $_SESSION["logged_in_mail"]; ?></span>
                </li>
            </ul>
        </div>
    </div>
